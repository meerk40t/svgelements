name = "svgelements"

from .svgelements import *